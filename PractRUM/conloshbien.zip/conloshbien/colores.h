#ifndef COLORES_H
#define COLORES_H
#include <iostream>
using namespace std;
enum tColor { rojo, verde, azul, amarillo, libre, blanco };//0,1,2,3

void colorTexto(tColor color);

#endif